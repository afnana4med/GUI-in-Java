import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OutputForm extends JFrame {
    /*
     * Require the private instance variables of inputData, number, and correct.
     */
    // instance variables TO DO
    private String inputData;
    private int number;
    private boolean correct;


    public OutputForm(String inputData, int number) {
        this.inputData = inputData;
        this.number = number;

        setTitle("Output Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Check the answer
        String result = "";
        String[] numberNames = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
                "twenty" };
        if (numberNames[number].equals(inputData.toLowerCase())) {
            result = new StringBuilder().append(inputData).append(" is CORRECT!").toString();
            this.correct = true;
        } else {
            result = new StringBuilder().append(inputData).append(" is INCORRECT!").toString();
            this.correct = false;
        }

        // Create components
        JLabel label = new JLabel(result);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 16)); // set font size
        JButton backButton = new JButton("Back");
        JButton quitButton = new JButton("Quit");

        // Create the logo label and set the ImageIcon
        ImageIcon logoIcon = new ImageIcon("sg_logo.png");
        JLabel logoLabel = new JLabel(logoIcon);

        // Add components to the second form
        JPanel panel = new JPanel(new BorderLayout());
        if (this.correct) {
            panel.add(logoLabel, BorderLayout.NORTH);
        }
        /*
         * Require label, backButton, and quitButton
         * to be added to the BorderLayout at the
         * appropriate compass point.
         */
        // TO DO
        panel.add(label,BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.WEST);
        panel.add(quitButton, BorderLayout.EAST);
        add(panel);

        // Register action listeners for buttons
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TO DO: Close the output form - see the InputForm for clues
                dispose();
            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Terminate the application
            }
        });
    }
}
