import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Random;

public class InputForm extends JFrame {
    private JTextField textField;
    private JLabel labelNumber;
    private JButton nextButton;
    private JButton quitButton;
    private boolean outputFormOpen;

    public InputForm() {
        setTitle("Input Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Create components
        Random random = new Random();
		ArrayList<Integer> numbers = (ArrayList<Integer>) Main.readRandomNumbers();
        int number;
        number = numbers.get(random.nextInt(1000));
        JLabel label = new JLabel("Enter the number as a name:");
        labelNumber = new JLabel("" + number);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 25)); // Increase font size
        labelNumber.setFont(labelNumber.getFont().deriveFont(Font.BOLD, 100)); // Increase font size
        labelNumber.setHorizontalAlignment(SwingConstants.CENTER); // Center the label horizontally
        textField = new JTextField(10);
        Font font = new Font(textField.getFont().getName(), Font.PLAIN, 25);
        textField.setFont(font);
        // nextButton instantiation TO DO
        nextButton = new JButton("Next");
        quitButton = new JButton("Quit");

        /*
         Add components to the main form using the five areas of BorderLayout Manager
         Note the compass has NORTH, WEST, SOUTH, and EAST points in English
         There is also the space called CENTER
        */
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(labelNumber, BorderLayout.NORTH);
        panel.add(label, BorderLayout.CENTER);
        // textField layout declaration required
        panel.add(textField, BorderLayout.SOUTH);
        panel.add(nextButton, BorderLayout.WEST);
        // quitButton layout declaration required
        panel.add(quitButton, BorderLayout.EAST);
        add(panel);

        // Register action listeners for buttons
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputData = textField.getText();
                if (!outputFormOpen) {
                    // instantiate the outputForm and pass inputData and number
                    // to its constructor.
                    // TO DO
                    OutputForm outputForm = new OutputForm(inputData, number);
                    outputFormOpen = true;
                    outputForm.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent windowEvent) {
                            outputFormOpen = false;
                        }
                    });
                    /* Make the output form visible - see Main class for a clue */
                    // TO DO
                    outputForm.setVisible(true);
                }

            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the input form
            }
        });
    }
}
