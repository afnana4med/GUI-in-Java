import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
  There is nothing wrong with this Main class!
*/

/*
 *  The application is designed to help a young person to learn
 *  the English names for numbers from one to twenty from
 *  the whole numbers, 0 through twenty, inclusive.
 */

public class Main {
    private static final String RANDOM_NUMBERS_FILE = "random_numbersD.txt";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                InputForm inputForm = new InputForm();
                inputForm.setVisible(true);
            }
        });
    }

    public static List<Integer> readRandomNumbers() {
        List<Integer> numbers = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(RANDOM_NUMBERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int number = Integer.parseInt(line);
                numbers.add(number);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return numbers;
    }
}